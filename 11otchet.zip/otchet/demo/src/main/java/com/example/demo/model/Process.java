package com.example.demo.model;


import javax.persistence.*;

@Entity
@Table(name = "process")
public class   Process {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idprocess")
    private int idprocess;
    @Column (name = "name")
    private String name;




    public int getIdprocess() {return idprocess;}
    public void setIdprocess(int idprocess){this.idprocess=idprocess;}

    public String getName(){return name;}
    public void setName(String name){this.name=name;}


}

