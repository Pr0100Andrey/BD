package com.example.demo.model;


import javax.persistence.*;
import java.sql.Time;
import java.sql.Timestamp;

@Entity
@Table(name = "timestart")


public class Timestart {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idtimestart")
    private int idtimestart;
    @Column(name = "dayweek")
    private String dayweek;
    @Column(name = "time")
    private Time time;
    @Column(name = "onlyone")
    private Timestamp onlyone;
    @Column(name = "proc")
    private int proc;
    @Column(name ="interval")
    private Timestamp interval;
    @Column(name = "mounth")
    private String mounth;

    public int getIdtimestart() {
        return idtimestart;
    }

    public void setIdtimestart(int idtimestart) {
        this.idtimestart = idtimestart;
    }

    public String getDayweek() {
        return dayweek;
    }

    public void setDayweek(String dayweek) {
        this.dayweek = dayweek;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public Timestamp getOnlyone() {
        return onlyone;
    }

    public void setOnlyone(Timestamp onlyone) {
        this.onlyone = onlyone;
    }

    public int getProc() {
        return proc;
    }

    public void setProc(int proc) {
        this.proc = proc;
    }

    public Timestamp getInterval() {
        return interval;
    }

    public void setInterval(Timestamp interval) {
        this.interval = interval;
    }

    public String getMounth() {
        return mounth;
    }

    public void setMounth(String mounth) {
        this.mounth = mounth;
    }
}
