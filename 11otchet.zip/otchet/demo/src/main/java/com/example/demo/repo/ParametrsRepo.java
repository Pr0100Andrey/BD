package com.example.demo.repo;

import com.example.demo.model.Parametrs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametrsRepo extends JpaRepository<Parametrs,Integer> {



}
