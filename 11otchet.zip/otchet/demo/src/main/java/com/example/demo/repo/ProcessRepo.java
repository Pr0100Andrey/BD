package com.example.demo.repo;

import com.example.demo.model.Process;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessRepo extends JpaRepository<Process, Integer> {



}
