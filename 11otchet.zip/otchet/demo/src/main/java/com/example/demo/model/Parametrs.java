package com.example.demo.model;


import javax.persistence.*;

@Entity
@Table(name = "parametrs")
public class Parametrs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)


    @Column (name="parametrs")
    private int idparametrs;

    @Column (name = "name")
    private String name;
    @Column (name = "parametr")
    private String  parametr;

    @Column (name = "proces")
    private int proces;

    public int getIdparametrs() {return idparametrs;}
    public void setIdparametrs(int idparametrs){this.idparametrs=idparametrs;}

    public String getName(){return name;}
    public void setName(String name){this.name=name;}

    public String getParametr(){return parametr;}
    public void setParametr(String parametr){this.parametr=parametr;}

    public int getProces() {return proces;}
    public void setProces(int process){this.proces=process;}



}

