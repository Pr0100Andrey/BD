package com.example.demo.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "time")

public class Time {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "idtime")
    private int idtime;

    @Column(name = "start")
    private Timestamp start;

    @Column(name = "end")
    private Timestamp end;

    @Column(name = "process")
    private  int process;

    public int getIdtime() {return idtime;}
    public void setIdtime(int idtime){this.idtime = idtime;}

    public  Timestamp getStart(){return start;}
    public  void setStart(Timestamp start){this.start=start;}

    public Timestamp getEnd(){return end;}
    public void setEnd(Timestamp end){this.end=end;}

    public int getProcess() {return process;}
    public void setProcess(int process){this.process=process;}





}
